
package com.example.examquestions;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    ArrayList<String> questions = new ArrayList<>();
    android.content.SharedPreferences prefs;

    int blue=Color.rgb(11,59,120);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("exam",MODE_PRIVATE);
        load();
        showHome();
    }

    TextView title(String s){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(22); t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(28,28,20,28); t.setGravity(Gravity.RIGHT);
        t.setBackgroundColor(blue); return t;
    }
    Button btn(String text){
        Button b=new Button(this); b.setText(text); b.setTextSize(16); b.setAllCaps(false);
        b.setPadding(12,18,12,18); return b;
    }
    void base(String name){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(243,246,251));
        root.addView(title("📚  "+name));
        ScrollView sv=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(24,24,24,24); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void showHome(){
        base("إعداد الأسئلة");
        addButton("➕  إنشاء امتحان",v->showCreate());
        addButton("📖  بنك الأسئلة ("+questions.size()+")",v->showBank());
        addButton("📄  الامتحانات المحفوظة",v->showSaved());
        TextView info=new TextView(this); info.setText("\nبرنامج لإعداد الأسئلة وتوليد الامتحانات للمدرسين."); info.setTextSize(17); info.setTextColor(Color.DKGRAY); content.addView(info);
    }
    void addButton(String s,View.OnClickListener l){Button b=btn(s); content.addView(b,new LinearLayout.LayoutParams(-1,70)); b.setOnClickListener(l);}
    EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16); e.setGravity(Gravity.RIGHT); content.addView(e,new LinearLayout.LayoutParams(-1,65)); return e; }
    void showBank(){
        base("بنك الأسئلة");
        addButton("➕ إضافة سؤال",v->addQuestion());
        if(questions.isEmpty()){TextView t=new TextView(this);t.setText("لا توجد أسئلة محفوظة.");t.setTextSize(17);content.addView(t);}
        for(int i=0;i<questions.size();i++){ TextView t=new TextView(this);t.setText((i+1)+" / "+questions.get(i));t.setTextSize(16);t.setPadding(10,18,10,18);t.setBackgroundColor(Color.WHITE);content.addView(t); }
        addButton("⬅ الرئيسية",v->showHome());
    }
    void addQuestion(){
        base("إضافة سؤال");
        EditText q=input("نص السؤال");
        EditText opts=input("الخيارات (اختياري)");
        EditText mark=input("الدرجة");
        addButton("💾 حفظ السؤال",v->{if(q.getText().toString().trim().isEmpty()){q.setError("اكتب السؤال");return;}
            questions.add(q.getText().toString()+" | "+opts.getText().toString()+" | "+mark.getText().toString());save();showBank();});
        addButton("⬅ رجوع",v->showBank());
    }
    void showCreate(){
        base("إنشاء امتحان");
        EditText subject=input("المادة");
        EditText grade=input("الصف");
        EditText n=input("عدد الأسئلة");
        addButton("🎲 اختيار الأسئلة وتوليد الامتحان",v->{
            int count=1; try{count=Integer.parseInt(n.getText().toString());}catch(Exception e){}
            if(questions.isEmpty()){new AlertDialog.Builder(this).setMessage("أضف أسئلة إلى بنك الأسئلة أولاً.").setPositiveButton("حسناً",null).show();return;}
            StringBuilder out=new StringBuilder();
            out.append("جمهورية العراق\nوزارة التربية\n\n");
            out.append("أسئلة امتحان: ").append(subject.getText()).append("\n");
            out.append("الصف: ").append(grade.getText()).append("\n\n");
            ArrayList<String> copy=new ArrayList<>(questions); Collections.shuffle(copy);
            count=Math.min(count,copy.size());
            for(int i=0;i<count;i++) out.append("س").append(i+1).append("/ ").append(copy.get(i)).append("\n\n");
            showPaper(out.toString());
        });
        addButton("⬅ الرئيسية",v->showHome());
    }
    void showPaper(String text){
        base("معاينة الامتحان");
        TextView p=new TextView(this); p.setText(text); p.setTextSize(18); p.setTextColor(Color.BLACK); p.setGravity(Gravity.RIGHT); p.setPadding(18,18,18,18); p.setBackgroundColor(Color.WHITE);
        content.addView(p,new LinearLayout.LayoutParams(-1,-2));
        addButton("🖨 طباعة / PDF",v->new AlertDialog.Builder(this).setMessage("واجهة الطباعة جاهزة للتطوير في الإصدار التالي.").setPositiveButton("حسناً",null).show());
        addButton("📝 Word",v->new AlertDialog.Builder(this).setMessage("تصدير Word سيضاف في الإصدار التالي.").setPositiveButton("حسناً",null).show());
        addButton("⬅ الرئيسية",v->showHome());
    }
    void showSaved(){ base("الامتحانات المحفوظة"); TextView t=new TextView(this);t.setText("سيتم حفظ نماذج الامتحانات وإدارتها هنا في النسخة التالية.");t.setTextSize(17);content.addView(t);addButton("⬅ الرئيسية",v->showHome());}
    void save(){getSharedPreferences("exam",0).edit().putString("q",String.join("\n",questions)).apply();}
    void load(){String s=prefs.getString("q","");if(!s.isEmpty())questions.addAll(Arrays.asList(s.split("\\n",-1)));}
}
